package com.example.joelcrawford.starbuzz;

public class Drink {
    private String name;
    private String description;
    private int imageResourceId;
    //drinks is an array of Drinks

    public static final Drink[] drinks ={
            new Drink("1.FILL ME WITH THE HOLY SPIRIT","1. FILL ME WITH THY HOLY SPORIT\n" +
                    "   I want to live each day as if the last one,\n" +
                    "   I want the truest values in my life,\n" +
                    "   For one day it will truly be my last one, \n" +
                    "   And I will have to leave this world behind.\n" + "\n" +

                    "   I want to make the most of every moment,\n" +
                    "   Redeeming to the fullest passing time,\n" +
                    "   By putting on His love and bowels of mercy,\n" +
                    "   And by grace put on His humbleness of mind.\n" + "\n" +

                    "\tCHORUS: " + "\n" +

                            "\tFill me with Thy Holy Spirit, fill me with eternal life,\n " +
                            "\tTo live each day as if it be my last one,\n" +
                            "\tFar above this world with all its carnal strife.\n" + "\n" +

                    "   The days I’ve wasted are not few but many,\n" +
                    "   I’m praying for a difference in my life,\n" +
                    "   Till all my friends and loved ones see me changing,\n" +
                    "   Till they see no longer me, but only Christ.\n" + "\n" +

                    "   Fill me with Thy Holy Spirit, my prayer is,\n" +
                    "   “please do not pass me by” " + "\n" +
                    "   Till grace o’er takes this weary pilgrim, \n" +
                    "   And I set my wings and like an eagle fly.\n",R.drawable.guitar),

            new Drink("2. HAVE YOU REALLY BEEN A FRIEND TO HIM?", "2. HAVE YOU REALLY BEEN A FRIEND TO HIM?\n" +
                    "   Do you live a life that’s true for the one who died for you?\n" +
                    "   Have you really been a friend to Him?\n" +
                    "   Have the deeds that you have done been for Christ the blessed one? \n" +
                    "   Have you really been a friend to Him?\n" +  "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tHave you really been a friend to Jesus?\n " +
                    "\tDo you falter when the pathway is dim?\n" +
                    "\tHave you really stood the test?\n " +
                    "\tHave you really done your best?\n " +
                    "\tHave you really been a friend to Him?\n" + "\n" +

                    "   When you set alone and pray, at the end of every day,\n" +
                    "   Have you really been a friend to Him?\n" +
                    "   Have you bravely faced the task? \n" +
                    "   Done the things He kindly asked? \n" +
                    "   Have you really been a friend to Him?\n" + "\n" +

                    "   Are you walking with the Lord, according to His word?\n" +
                    "   Have you really been a friend to Him?\n" +
                    "   Have you tried and tried again, for some precious souls to win?\n" +
                    "   Have you really been a friend to Him?", R.drawable.guitar),

            new Drink("3. YOU CAN’T LOSE WITH GOD ON YOUR SIDE","3. YOU CAN’T LOSE WITH GOD ON YOUR SIDE\n" +
                    "   There’s a road that you travel, it comes filled with stones, \n" +
                    "   And your heart’s so heavy that you can’t carry on,\n" +
                    "   I wonder if lately in your sorrow you’ve tried,\n" +
                    "   To walk down the pathway with God on your side.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tYou can’t lose, you’ll never lose, with God on your side,\n " +
                    "\tYou’ll win, you’ll win, if with Him you’ll abide,\n" +
                    "\tThe door is always open, if you will step inside,\n" +
                    "\tYou can’t lose, you’ll never lose, with God on your side,\n" + "\n" +

                    "   Do you feel you’re forsaken, that life is a loss\n" +
                    "   Just remember that Jesus, He felt the same way on the cross,\n " +
                    "   He cried out, “Oh, Father, hast thou forsaken me?”\n" +
                    "   His cries were our passport to life eternally.\n" + "\n" +

                    "   So friend, why would you tarry, to enter in,\n" +
                    "   This could be the last time that you would ever hear,\n" +
                    "   That Heavenly call, that’s tugging at your heart,\n" +
                    "   Why not come to Jesus and get a new start.",R.drawable.guitar),
            new Drink( "4. O COME ANGEL BAND","  4. O COME ANGEL BAND\n" +
                    "   My latest sun is sinking fast, my race is nearly run,\n" +
                    "   My strongest trials now are past, my triumph is began!\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tO come, angel band, come and around me stand,\n" +
                    "\tO bear me away on your snowy wings, to my immortal home, \n" +
                    "\tO bear me away on your snowy wings, to my immortal home,\n" + "\n" +

                    "   I know I’m nearing holy ranks, of friends and kindred dear,\n" +
                    "   I brush the dew of Jordan’s banks, the crossing must be near.\n" + "\n" +

                    "   I’ve almost gained my Heavenly home, my spirit loudly sings, \n" +
                    "   The holy ones, behold, they come! I hear the noise of wings.\n" + "\n" +

                    "   O bear my longing heart to Him, who bled and died for me,\n" +
                    "   Whose blood now cleanses from all sin, and gives me victory.",R.drawable.guitar ),
            new Drink( "5. LIFE’S RAILWAY TO HEAVEN","5. LIFE’S RAILWAY TO HEAVEN\n" +
                    "   Life is like a mountain rail road, with an engineer that’s brave,\n" +
                    "   We must make the run successful, from the cradle to the grave,\n" +
                    "   Watch the curves, the fills, the tunnels, never falter, never quail,\n" +
                    "   Keep your hand upon the throttle, and your eyes upon the rail.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tBlessed savior, Thou wilt guide us, till we reach that blissful shore,\n" +
                    "\tWhere the angels wait to join us, in Thy praise forevermore.\n" + "\n" +

                    "   You will roll up grades of trail, you will cross the bridge of strife,\n" +
                    "   See that Christ is your conductor on this light’ning train of life,\n" +
                    "   Always mindful of obstruction, do your duty, never fail,\n" +
                    "   Keep your hand upon the throttle, and your eyes upon the rail.\n" + "\n" +

                    "   You will often find obstruction, look for storms of wind and rain,\n" +
                    "   On a fill, a curve, or trestle, they will almost ditch your train,\n" +
                    "   Put your trust alone in Jesus, never falter, never fail\n" +
                    "   Keep your hand upon the throttle, and your eyes upon the rail.\n" + "\n" +

                    "   As you roll across the trestle, spanning Jordan’s swelling tide,\n" +
                    "   There behold the union depot into which your train will glide,\n" +
                    "   There you’ll meet the Superintendent, God the Father, God the Son,\n" +
                    "   With a hearty joyous plaudit “ weary pilgrim, welcome home”",R.drawable.guitar),

            new Drink( "6. JUST BEFORE THE BATTLE MOTHER","6. JUST BEFORE THE BATTLE MOTHER\n" +
                    "   Just before the battle, Mother, I was thinking most of you,\n" +
                    "   While upon the field we’re marching, with our enemies in view\n" +
                    "   Comrades brave around me weeping, thinking of our home and God\n" +
                    "   For we know that on the morrow, some will sleep beneath the sod\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tFarewell, mother, you may never see me on this earth again,\n" +
                    "\tOh, do not forget me, mother, if I be numbered with the slain.\n" + "\n" +

                    "   Hark! I hear the bugle playing, we are ready for the fight\n" +
                    "   Oh, may God protect us, mother, as He ever does the right\n" +
                    "   Savior come and stand beside me, by the old red, white and blue\n" +
                    "   And we’ll all be reunited, in America brave and true.",R.drawable.guitar),

            new Drink("7. HE SIGNED THE PARDON","7. HE SIGNED THE PARDON\n" +
                    "   Jesus, my Lord, paid the greatest price, there on the cross, He gave His own life,\n" +
                    "   For a worthless, no good, a sinner such as I, He freely chose to suffer and die.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tHe signed the pardon, He signed the pardon\n" +
                    "\tHe paid the debt that truly set me free\n" +
                    "\tHe signed the pardon, He signed the pardon\n" +
                    "\tBut I must receive that pardon unto me.\n" + "\n" +

                    "   The word has been spoken and I was condemned, All hope was gone and hell was my end\n " +
                    "   The sentence was written and someone must die, But Jesus choose to give His own life.\n" + "\n" +

                    "   The pardon is mine, if I can receive, it’s not enough to just understand or believe\n" +
                    "   There are millions that claim that pardon for their own,\n" +
                    "   But will never make Heaven their home\n" + "\n" +

                    "   Receiving the pardon is not that hard to claim,\n" +
                    "   But you must receive the one He sends in His name\n" +
                    "   Rejecting His Servant brings an awful fate,\n" +
                    "   So make sure where you stand, before it’s too late.",R.drawable.guitar),
            new Drink( "8. A HOME WITHOUT A DADDY" ,"8. A HOME WITHOUT A DADDY\n" +
                    "   So many homes in our great land today, won’t feel like home ‘cause daddy is away,\n" +
                    "   The children need their daddy’s guiding hand, to lead them and help them understand.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tA home without a daddy is no home, Without a daddy every Joy is gone,\n" +
                    "\tA home without a daddy to love, Displeases our Saviour above.\n" + "\n" +

                    "   Today so many daddies are in sin, so foolishly, they’ve let old satan in,\n" +
                    "   If they’d repent, I know God would forgive, and someday up in Heaven hey would live.\n" + "\n" +

                    "   Tomorrow may be too late to begin, for no one knows when He will come again,\n" +
                    "   Our Saviour said that we must wait and pray, and He will come to take us home someday.\n",R.drawable.guitar),
            new Drink( "9. FALLEN LEAVES","9. FALLEN LEAVES\n" +
                    "   Lord, let my eyes see the love in every man,\n" +
                    "   Let me stop and always lend a helping hand,\n" +
                    "   And when I’m laid beneath that little grassy mound,\n" +
                    "   There’ll be more friends than leaves upon the ground.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tFallen leaves that lie scattered on the ground\n" +
                    "\tThe birds and flowers that were here cannot be found\n" +
                    "\tAll the friends he ever had are not around\n" +
                    "\tThey are scattered like the leaves upon the ground.\n" + "\n" +

                    "   Some folks drift along through life and never thrill\n" +
                    "   To the feeling that a good deed brings until\n" +
                    "   It’s too late and they are ready to lie down\n" +
                    "   There beneath the leaves scattered on the ground.\n" + "\n" +

                    "   To your grave there’s no use taking any gold,\n" +
                    "   You can’t use it when it’s time for hands to fold,\n" +
                    "   When you leave this earth for a better home someday,\n" +
                    "   The only thing you take is what you gave away.",R.drawable.guitar),
            new Drink( "10. SATISFIED MIND","10. SATISFIED MIND\n" +
                    "   How many times have you heard someone say,\n" +
                    "   If I had this money, I could do things my way\n" +
                    "   But little do they know that it’s so hard to find,\n" +
                    "   One rich man in ten with a satisfied mind.\n" + "\n" +

                    "   Once I was winning in fortune and fame,\n" +
                    "   Everything that I longed for to get a start in lives game,\n" +
                    "   But suddenly it happened, I lost every dime,\n" +
                    "   But I’m richer by far with a satisfied mind.\n" + "\n" +

                    "   Money can’t buy back your youth when you are old,\n" +
                    "   A friend when you’re lonely or a love that’s grown old,\n" +
                    "   The wealthiest person is a pauper at times,\n" +
                    "   Compared to the man with a satisfied mind.\n" + "\n" +

                    "   When life has ended my time has run out,\n" +
                    "   My friends and my loved ones, I’ll leave them no doubt,\n" +
                    "   But there’s one thing for certain when it come my time,\n" +
                    "   I will leave this old world with a satisfied mind.",R.drawable.guitar ),
            new Drink( "11. AUTOMOBILE LIFE","11. AUTOMOBILE LIFE\n" +
                    "   Some people are just like an automobile,\n" +
                    "   They’ll run fine when everything’s right\n" +
                    "   When the roads are all clear and the weather is fine,\n" +
                    "   And there is plenty of sunshine and light\n" +
                    "   But often they come to a wash-out and then, get stuck and have to detour\n" +
                    "   May be a break in the testing will prove, they never were meant to endure.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tGet plenty of water and plenty of oil,\n" +
                    "\tAnd the best gasoline you can find\n" +
                    "\tHave your engine tuned up and look out for your breaks,\n" +
                    "\tYou’ll have some hard places to climb,\n" +
                    "\tLook out for the tires, for the blowouts will come\n" +
                    "\tOn a dangerous curve, keep an eye,\n" +
                    "\tBut, if you let Jesus take hold of the wheel," +
                    "\tYou’ll make it to heaven on high.\n" + "\n" +

                    "   Now all our professions, of powder and paint,\n" +
                    "   Get lovely upon the outside,\n" +
                    "   Won’t answer for God look on the heart, It matter not how hard we try.\n" +
                    "   So if you are stuck in the quicksand of sin,\n" +
                    "   Of wandering and floundering about,\n" +
                    "   Just let God’s great engine of glory and grace,\n" +
                    "   With a cable of love pull you out.",R.drawable.guitar ),
            new Drink( "12. THE OLD COUNTRY CHURCH","12. THE OLD COUNTRY CHURCH\n" +
                    "   There’s a place deer to me where I’m longing to be,\n" +
                    "   With my friends in the old country church\n" +
                    "   There with mother we went, and our Sundays were spent,\n" +
                    "   With my friends in the old country church.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tPrecious years, of memory,\n" +
                    "\tO what Joy they bring to me,\n" +
                    "\tHow I long once more to be,\n" +
                    "\tWith my friends in the old country church.\n" + "\n" +

                    "   As a small country boy how my heart beat with Joy,\n" +
                    "   When I knelt in the old country church,\n" +
                    "   And the Saviour above, by His wonderful love,\n" +
                    "   Saved my Soul in the old country church.\n" + "\n" +

                    "   How I wish that today, all the people would pray,\n" +
                    "   As we prayed in the old country church,\n" +
                    "   If they’d only confess Jesus surely would bless,\n" +
                    "   As He did in the old country church.\n" + "\n" +

                    "   Oft my thoughts make me weep, for so many now sleep,\n" +
                    "   In their graves near the old country church,\n" +
                    "   And sometimes, I may rest with the friends I love best,\n" +
                    "   In a grave near the old country church.",R.drawable.guitar),
            new Drink( "13. SHAKE HANDS WITH MOTHER AGAIN","13. SHAKE HANDS WITH MOTHER AGAIN\n" +
                    "   If I should be living when Jesus comes, and could know the day and the hour,\n" +
                    "   I’d like to be standing at mother’s tomb, when Jesus comes in His power.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\t‘Twill be a wonderful happy day, up there by the golden strand,\n" +
                    "\tWhen I can hear Jesus, my Saviour say, shake hands with mother again.\n" + "\n" +

                    "   I’d like to say “mother this is your boy,you left when you went away” \n" +
                    "   And I can see Jesus upon His throne, in that bright city, so fair.\n" + "\n" +

                    "   There’s coming a time when I can go home, to meet my loved ones up there,\n" +
                    "   There I can see Jesus upon His throne, in that bright city, so far.\n" + "\n" +

                    "   There’ll be no more sorrow or pain to bear, in that home beyond the sky,\n" +
                    "   O glorious thought when we all get there, we never will say “good-bye”.",R.drawable.guitar),
            new Drink( "14. THIS WORLD IS NOT MY HOME","14. THIS WORLD IS NOT MY HOME\n" +
                    "   This world is not my home, I’m just a passing through,\n" +
                    "   My treasures are laid up somewhere beyond the blue,\n " +
                    "   The angels beckon me from Heaven’s open door,\n" +
                    "   And I can’t feel at home in this world anymore.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tO Lord, you know I have no friend like you,\n" +
                    "\tIf Heaven’s not my home then Lord what will I do,\n" +
                    "\tThe angels beckon me from Heaven’s open door, \n" +
                    "\tAnd I can’t feel at home in this world anymore.\n" + "\n" +

                    "   They’re all expecting me, and that’s one thing I know,\n" +
                    "   My Saviour pardoned me and now I onward go,\n" +
                    "   I know He’ll take me through though I am weak and poor,\n" +
                    "   And I can’t feel at home in this world anymore.\n" + "\n" +

                    "   I have a loving mother up in glory land,\n" +
                    "   I don’t expect to stop, until I shake her hand,\n" +
                    "   She’s waiting now for me, in Heaven’s open door,\n" +
                    "   And I can’t feel at home in this world anymore.\n" + "\n" +

                    "   Just up in glory land we’ll live eternally,\n" +
                    "   The saints on ev’ry hand are shouting victory,\n" +
                    "   Their song of sweetest praise drifts back from Heaven’s shore,\n" +
                    "   And I can’t feel at home in this world anymore.",R.drawable.guitar ),
            new Drink( "15. THE PICTURE ON THE WALL","15. THE PICTURE ON THE WALL\n" +
                    "   There’s an old and faded picture on the wall,\n" +
                    "   It’s been hanging there for many, many years,\n" +
                    "   It’s the picture of my mother, and I know there is no other,\n" +
                    "   That can take the place of mother on the wall.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tOn the wall, on the wall, How I love that old picture on the wall,\n" +
                    "\tTime is swiftly passing by, and I bow my head and cry,\n" +
                    "\tBut I know I’ll meet my mother after all.\n" +  "\n" +

                    "   Since I lost that dear old mother years ago,\n" +
                    "   There is none to which with troubles I can go,\n" +
                    "   As my guitar makes this chord I am praying to the Lord,\n" +
                    "   Let me hold that old picture on the wall.\n" + "\n" +

                    "   Now the children all have scattered, all have gone,\n" +
                    "   And I have a little family of my own,\n" +
                    "   And I know I love them well, more than any tongue can tell,\n" +
                    "   But I’ll hold that dear old picture on the wall.\n",R.drawable.guitar ),
            new Drink( "16. WHERE THE SOUL OF MAN NEVER DIES","16. WHERE THE SOUL OF MAN NEVER DIES\n" +
                    "   To Canaan’s land, I’m on my way, where the soul (of man) never dies,\n" +
                    "   My darkest night will turn to day, where the soul (of man) never dies.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tNo sad farewells (Dear friends, there’ll be no sad farewells)\n" +
                    "\tNo tear-dimmed eyes (There’ll be no tear-dimmed eyes) \n" +
                    "\tWhere all is love (Where all is peace and Joy and Love)\n" +
                    "\tAnd the soul (of man) never dies.\n" + "\n" +

                    "   A rose is blooming there for me, where the soul (of man) never dies,\n" +
                    "   It shines to light the shores of home, where the soul (of man) never dies.\n" + "\n" +

                    "   A love light beams across the foam, where the soul (of man) never dies,\n" +
                    "   It shines to light the shores of home, where the soul (of man) never dies.\n" + "\n" +

                    "   My life will end in deathless sleep, where the soul (of man) never dies,\n" +
                    "   And everlasting Joys I’ll reap, where the soul (of man) never dies.\n" + "\n" +

                    "   I’m on my way to that fair land, where the soul (of man) never dies,\n" +
                    "   Where there will be no parting hand, where the soul (of man) never dies.",R.drawable.guitar),
            new Drink( "17. NEITHER DO I CONDEMN THEE","17. NEITHER DO I CONDEMN THEE\n" +
                    "   By a crowd of worshipers, sorry for their sins, \n" +
                    "   Was a poor wanderer, rudely brought in,\n" +
                    "   Scribes came and Pharisees, Anxious to see,\n" +
                    "   What the meek Nazarene’s verdict would be.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\t“Neither do I condemn thee”, precious word divine,\n" +
                    "\tFrom the lips of mercy, like the sweetest chimes,\n" +
                    "\tWonderful words of Jesus, sing them o’er and o’er\n, " +
                    "\t“Neither do I condemn thee, go and sin no more”\n" +  "\n" +

                    "   They told of her wonderings, making each flaw,\n" +
                    "   Spoke of her punishment, Quoting the law,\n" +
                    "   Writing upon the ground, sadly and slow,\n" +
                    "   But said He unheedingly, head bending low.\n" + "\n" +

                    "   Still cried the Pharisees, “pray woman pray,\n" +
                    "   What shall we do with her? What doth thou say?”\n" +
                    "   Then said He rebukingly, “Let the first stone,\n" +
                    "   Come from the sinless hands, hence and alone”\n" + "\n" +

                    "   Cheeks flushing with the shame, turning about,\n " +
                    "   And from His presence, walking slowly out,\n" +
                    "   Then saw we standing there, head bending low,\n " +
                    "   He who the world despised, bade her sin no more.\n" + "\n" +

                    "   Spoke He most tenderly, “pray woman pray,\n" +
                    "   Hast thou no accusers?” “Nay, Master, Nay”\n" +
                    "   “Neither do I condemn thee, soul, sick and sore,\n" +
                    "   Go forth, I pardon thee, go and sin no more”.",R.drawable.guitar),
            new Drink( "18. THANK GOD I’M FREE","\n" +
                    "18. THANK GOD I’M FREE\n" +
                    "   For a long time I travelled down along lonely road,\n" +
                    "   My heart was so heavy, in sin I sank low,\n" +
                    "   Then I heard about Jesus, what a wonderful hour,\n" +
                    "   I’m so glad that I found out He would bring me out thro His saving power.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tThank God, I am free, free, free from this world of sin,\n" +
                    "\tWashed in the blood of Jesus, been born again,\n" +
                    "\tHallelujah, I’m saved, saved, saved by His wonderful grace,\n" +
                    "\tI’m so glad that I found out He would bring me out and show me the way.\n" + "\n" +

                    "   Like a bird out of prison, that’s taken its flight,\n" +
                    "   Like the blind man that God gave back his sight,\n" +
                    "   Like the poor wretched beggar, that’s found fortune and fame,\n" +
                    "   I’m so glad that I found out He would bring me out thro’ His Holy name.",R.drawable.guitar ),
            new Drink( "19. THAT IS THE MAN I’M LOOKING FOR","19. THAT IS THE MAN I’M LOOKING FOR\n" +
                    "   If you see a man in sandals, please send Him down my way,\n" +
                    "   It might be my Master, He’s coming back someday,\n" +
                    "   If you see a man in white, that’s like no one you’ve seen before,\n" +
                    "   Won’t you let me know, that’s the man I’m looking for.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tAnd if you can remember, ask Him what’s His name.\n" +
                    "\tAnd if He tells you Jesus, say, “we’re so glad you came” \n" +
                    "\tTell Him you know someone who still calls Him Lord, \n" +
                    "\tThen send Him on to me, that’s the man I’m looking for.\n" + "\n" +

                    "   If you see a man that shines with, a love glow on His face,\n" +
                    "   Turn Him down my street, so He can find my place,\n" +
                    "   And if His hands are scarred, please don’t shut the door,\n" +
                    "   Just send Him on to me, that’s the man I’m looking for.",R.drawable.guitar ),
            new Drink( "20. I NEED THE PRAYERS","   20. I NEED THE PRAYERS\n" +
                    "   I need the prayers of those I love, while trav’lling o’er life’s rugged way,\n " +
                    "   That I may true and faithful be, and live for Jesus every day.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI want my friends to pray for me, to bear my tempted soul above,\n" +
                    "\tAnd intercede with God for me, I need the prayers of those I love.\n" + "\n" +

                    "   I need the prayers of those I love, to help me in each trying hour,\n" +
                    "   To bear my tempted soul to Him, that He may keep me by His pow’r.\n" + "\n" +

                    "   I want my friends to pray for me, to hold me up on wings of faith,\n" +
                    "   That I may walk the narrow way, kept by our Father’s glorious grace.",R.drawable.guitar),
            new Drink( "21 A. BEULAH LAND","    21 A. BEULAH LAND\n" +
                    "   I’m kind of homesick for a country, to which I’ve never been before,\n" +
                    "   No sad goodbyes will there be spoken, for time won’t matter anymore.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tBeulah land, I’m longing for you, and some day, on thee I’ll stand,\n" +
                    "\tThere my home shall be eternal. Beulah land, sweet Beulah land.\n" + "\n" +

                    "   I’m looking now across the river, there my faith will end in sight,\n" +
                    "   There’s just a few more days to labour, then I will take my heav’nly flight.",R.drawable.guitar ),
            new Drink( "21 B. WHAT SINS ARE YOU TALKING ABOUT","    21 B. WHAT SINS ARE YOU TALKING ABOUT\n" +
                    "   I remember the days when I was bent low with the burden of sin and strife,\n" +
                    "   Then Jesus came in and rescued me, and He gave me a brand new life,\n" +
                    "   And now as I thank Him day after day for washing my sins away,\n" +
                    "   It seems I can almost hear the voice of the Blessed Saviour say.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tWhat sins are you talking about, I don’t remember them anymore,\n" +
                    "\tFrom the book of life, they’ve all been torn out,\n" +
                    "\tI don’t remember them anymore.\n" + "\n" +

                    "   When my flesh becomes weak, it’s then I can speak to the Saviour,\n" +
                    "   Who’s with me each day Oh, Father, forgive me, hear my plea and wash my sins away,\n" +
                    "   Each time that I bow to give Him thanks for removing my guilt and shame,\n" +
                    "   He cannot recall what I’m talking about, for His answer is always the same.",R.drawable.guitar),
            new Drink( "22. COUNT YOUR BLESSINGS"," 22. COUNT YOUR BLESSINGS\n" +
                    "   When upon life’s billows you are tempest tossed,\n" +
                    "   When you are discouraged, thinking all is lost\n" +
                    "   Count your many blessings, name them one by one,\n" +
                    "   And it will surprise you what the Lord hath done.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tCount your blessings, name them one by one, \n" +
                    "\tCount your blessings, see what God hath done,\n" +
                    "\tCount your blessings, name them one by one,\n" +
                    "\tCount your many blessings, see what God hath done,\n" + "\n" +

                    "   Are you ever burdened with a load of care?\n" +
                    "   Does the cross seem heavy you are called to bear?\n " +
                    "   Count your many blessings, ev’ry doubt will fly,\n" +
                    "   And you will be singing as the days go by.\n" + "\n" +

                    "   When you look at others with their lands and gold,\n " +
                    "   Think that Christ has promised you His wealth,\n" +
                    "   Untold, Count your many blessings, money cannot buy,\n" +
                    "   Your reward in Heaven nor your Home on high.\n" + "\n" +

                    "   So, amid the conflict, whether great or small,\n" +
                    "   Do not be discouraged, God is over all,\n" +
                    "   Count your many blessings, angels will attend,\n" +
                    "   Help and comfort give you to your journey’s end.",R.drawable.guitar )

    };
    //each drink has a name, description and imageResourceId
    private Drink(String name, String description, int imageResourceId){
        this.name = name;
        this.description=description;
        this.imageResourceId=imageResourceId;

        }


    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getImageResourceId() {
        return imageResourceId;
    }
    public String toString(){
        return this.name;
    }
}
